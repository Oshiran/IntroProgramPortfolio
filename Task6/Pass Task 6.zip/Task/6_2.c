#include <stdio.h>
#include <stdlib.h>
#include "input_functions.h"

#define PLAYERS 4

/**
 * This function will prompt user to enter the individual
 * score of each player for all teams
 * (Each team consists of four players).
 * All the input will be stored in the array
 */
void input(int** array, int number_of_teams, int number_of_players){
    // Fill in the blank
}

void disp_array(int ** array,int number_of_teams, int number_of_players){
    // Fill in the blank
}

int teamscore(int * array, int number_players){
    // Fill in the blank
}

int** create2DArray(int teams, int players){
    // Fill in the blank
}

void free2DArray(int** array, int teams){
    for(int i = 0 ; i < teams; i++){
        free(array[i]);
    }

    free(array);
}

void main(){
    //  prompt user to enter total number of teams
    int number_of_teams = ...

    // Call "create2DArray" array of teams and players
    int ** array = ...

    // Call "input" to populate team score

    // Call "disp_array" to display team score

    // Print sum of team score here

    free2DArray(array, number_of_teams);
}