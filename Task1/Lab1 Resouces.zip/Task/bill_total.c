#include <stdio.h>

void main()
{
    int appetizer_price;
    int main_price;
    int dessert_price;
    int total_price;

    printf("Enter the appetizer price (in cents)\n");
    /* Insert scanf here */

    printf("Enter the main price (in cents)\n");
    /* Insert scanf here */

    printf("Enter the dessert price (in cents)\n");
    /* Insert scanf here */

    total_price = /* missing code */ ;
    printf(/* missing code */);
}
